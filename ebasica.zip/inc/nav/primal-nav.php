<?php 
/** Botones para compartir en redes sociales. Estilo ANLI
------------------------------------------------------------------- */ 
?>
<nav id="header-main-nav" class="primalMainNav" role="navigation">
    <!-- Icono de menú para versión adaptativa -->
    <a class="toggle-nav" href="#">MENU DE NAVEGACIÓN</a>
    <!-- Menu WordPress -->
    <div class="activo">
    	<ul>
    		<li>
    			<a href="/onepage.hipermedia.in/" class="active">Inicio</a>
    		</li>
    		<li class="">
    			<a href="/onepage.hipermedia.in/pagina-ejemplo/">¿En qué es efectivo?</a>
    		</li>
    	</ul>
    </div>
</nav>