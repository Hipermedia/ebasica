<?php
/**
 * Template Name: Estadísticas
 */

get_header(); ?>
   <section class="Estadisticas">

    <?php the_breadcrumb();  ?>
      <!-- Título del artículo -->
      <h1 class="Estadisticas-title"><?php the_title(); ?></h1>
      <!-- Contenido -->
      <?php the_content(); ?>

      <?php global $post; ?>
      <?php  
         $idPadre = $post->post_parent;
         $args = array( 'page_id' => $idPadre, 'meta_key' => 'gridDireccion' ); 
         $consulta_acf_img = new WP_Query( $args ); 
      ?>
      <?php if ( $consulta_acf_img->have_posts() ) : ?>
         <?php while ( $consulta_acf_img->have_posts() ) : $consulta_acf_img->the_post(); ?>
            <?php if(get_field('gridDireccion')) : ?>
            <?php $imagen = get_field('gridDireccion'); ?>
            <?php $img = $imagen[2]; ?>
            <?php $primera = $img['imagen']; ?>
            <?php endif; ?>
            <?php if($primera!="") { $style = "background-image: url(".$primera.");"; } else { $style = ""; } ?>
         <?php endwhile; ?>
         <?php wp_reset_postdata(); ?>
      <?php endif; ?>

      <div class="Estadisticas-encabezado">
         <div class="Estadisticas-encabezadoIcono" style="<?php echo $style; ?>"></div>
         <div class="Estadisticas-encabezadoContenedor">
            <h3 class="Estadisticas-encabezadoContenedor-titulo">Estadisticas</h3>
            <span class="Estadisticas-encabezadoContenedor-icon u-icon-pdf"></span>  
         </div>
      </div>
      
      <?php $args = array( 'posts_per_page' => 4, 'cat' => 13, 'meta' => 'postArchivoDescripcion', 'author' => $post->post_author) 
      ?>
      <?php $consulta = new WP_Query( $args ); ?>
      <?php $xyz = 0; ?>
      <?php while ( $consulta->have_posts() ) : $consulta->the_post(); ?>
      <?php $xyz++; ?>
      <div class="Estadisticas-bloque u-border-estadisticas">
         <div class="Estadisticas-bloqueIcono u-icono-estadisticas"></div>
         <div class="Estadisticas-bloqueContenido u-padding-estadisticas">
           <h2 class="Estadisticas-bloqueContenido-titulo u-titulo-estadisticas">
            <?php the_title(); ?>
           </h2>
           <p class="Estadisticas-bloqueContenido-data">
            Publicado el <?php the_time(get_option('date_format')); ?>
           </p>
           <div id="expand<?php echo $xyz; ?>" class="Estadisticas-bloqueContenido-texto">
            <?php the_field('postArchivoDescripcion'); ?>
           </div>
           <a href="" class="u-link">descargar</a>
           <p id="trigger-expand<?php echo $xyz; ?>" class="u-link">ver más</p>
         </div>
      </div>
      <script>
         jQuery('#trigger-expand<?php echo $xyz; ?>').click(function() {
             jQuery('#expand<?php echo $xyz; ?>').toggleClass('appear');
             jQuery('#expand<?php echo $xyz; ?>').toggleClass('animated fadeIn');
         });
      </script>
      <?php endwhile; // end of the loop. ?>
      <?php the_custom_numbered_nav( $consulta ); ?> 
      <?php wp_reset_postdata(); ?>
   </section>
<?php get_footer(); ?>
