 == TEMA WORDPRESS BASE ONE PAGE DE SOLUCIONES HIPERMEDIA ==

Nombre del tema: SH One Page Dev
Autor: Soluciones Hipermedia
Web del author: http://www.solucioneshipermedia.com/
Description: Tema base Wordpress para desarrollo de proyectos de Soluciones Hipermedia del tipo Sitio Efectivo One Page
Version: 1.0
Text Domain: shonepage
